from wlan import do_connect
do_connect('my wifi', 'simsalabim')

from enc_oscclient import main
main()
